package com.spring.sTiles;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/tiles")
public class TilesController {

	// 로그인처리
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPost(String mid, String pwd) {
		if(mid.equals("admin") && pwd.equals("1234")) {
			System.out.println("로그인되었습니다.");
		}
		else {
			System.out.println("로그인 실패~~");
			return "redirect:/login";
		}
		return "member/memberMain";
	}
	
	@RequestMapping(value = "/tilesHome", method = RequestMethod.GET)
	public String tilesHomeGet() {
		return "member/memberMain";
	}
	
	@RequestMapping(value = "/guestList", method = RequestMethod.GET)
	public String guestListGet() {
		return "guest/guestList";
	}
	
	@RequestMapping(value = "/boardList", method = RequestMethod.GET)
	public String boardListGet() {
		return "board/boardList";
	}
	
	@RequestMapping(value = "/pdsList", method = RequestMethod.GET)
	public String pdsListGet() {
		return "pds/pdsList";
	}
	
	@RequestMapping(value = "/myInfo", method = RequestMethod.GET)
	public String myInfoGet() {
		return "member/myInfo";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutGet() {
		return "redirect:/login";
	}
}
