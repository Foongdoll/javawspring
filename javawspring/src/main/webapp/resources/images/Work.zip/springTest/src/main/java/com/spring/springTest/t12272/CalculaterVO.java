package com.spring.springTest.t12272;


public class CalculaterVO {
	private int su1;
	private int su2;
	
	public int getSu1() {
		return su1;
	}
	public int setSu1(int su1) {
		int res = 0;
		if(su1 > 0 && su1 < 100) {
			this.su1 = su1;
		}
		else {
			res = 1;
		}
		
		return res;
	}
	public int getSu2() {
		return su2;
	}
	public int setSu2(int su2) {
		int res = 0;
		
		if(su2 > 0 && su2 < 100) this.su2 = su2;
		else res = 1;
		
		return res;
	}
	
	@Override
	public String toString() {
		return "Calculater [su1=" + su1 + ", su2=" + su2 + "]";
	}
	
	
}
