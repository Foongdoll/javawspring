package com.spring.springTest.t12283;

public class CalculaterVO {
	private int su1;
	private int su2;
	
	private CalculaterService se = new CalculaterService();
	
	public CalculaterVO(int su1, int su2) {
		this.su1 = su1;
		this.su2 = su2;
	}

	public void add() {
		se.add(su1, su2);
	}
	public void sub() {
		se.sub(su1, su2);
	}
	public void mul() {
		se.mul(su1, su2);
	}
	public void div() {
		se.div(su1, su2);
	}
	
}
