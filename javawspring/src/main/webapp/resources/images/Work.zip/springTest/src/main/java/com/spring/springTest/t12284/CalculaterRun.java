
package com.spring.springTest.t12284;

import org.springframework.context.support.ClassPathXmlApplicationContext;

// 값주입방법 (XML을 이용한 값의 주입)
public class CalculaterRun {
	public static void main(String[] args) {
		//AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:xml/t12284Beans.xml");
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("xml/t12284Beans.xml");
		
		
		CalculaterVO vo = (CalculaterVO)ctx.getBean("vo");
		
		vo = (CalculaterVO)ctx.getBean("vo");
		vo.add();
		vo.sub();
		vo.mul();
		vo.div();
		System.out.println();
		vo = (CalculaterVO)ctx.getBean("vo2");
		vo.add();
		vo.sub();
		vo.mul();
		vo.div();
		
		
		ctx.close();
	}
}
