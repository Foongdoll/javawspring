package com.spring.springTest.t12281;

import java.util.Scanner;


// 값주입방법 (setter를 이용한 값의 주입)
public class CalculaterRun {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CalculaterVO vo = new CalculaterVO();
		
		System.out.println("첫번쨰 수를 입력해주세요.");
		vo.setSu1(sc.nextInt());
		System.out.println("두번쨰 수를 입력해주세요.");
		vo.setSu2(sc.nextInt());
		
		CalculaterService se = new CalculaterService();
		
		se.add(vo.getSu1(), vo.getSu2());
		se.sub(vo.getSu1(), vo.getSu2());
		se.mul(vo.getSu1(), vo.getSu2());
		se.div(vo.getSu1(), vo.getSu2());
		
	
		sc.close();
	}
}
