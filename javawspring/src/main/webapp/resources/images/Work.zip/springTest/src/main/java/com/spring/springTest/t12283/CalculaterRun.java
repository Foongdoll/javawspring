
package com.spring.springTest.t12283;
import java.util.Scanner;


// 값주입방법 (생성자를 이용한 값의 주입 2)
public class CalculaterRun {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("첫번쨰 수를 입력해주세요.");
		int su1 = sc.nextInt();
		System.out.println("두번쨰 수를 입력해주세요.");
		int su2 = sc.nextInt();
		CalculaterVO vo = new CalculaterVO(su1, su2);
		
		vo.add();
		vo.sub();
		vo.mul();
		vo.div();
		
		sc.close();
	}
}
