package com.spring.springTest.t12286;

public class FireMan implements Actor {
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void getCasting() {
		System.out.println(name+"님는 소방관입니다.");
	}

}
