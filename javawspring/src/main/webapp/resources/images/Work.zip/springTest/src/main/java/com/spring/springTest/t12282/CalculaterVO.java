package com.spring.springTest.t12282;

public class CalculaterVO {
	private int su1;
	private int su2;
	
	public CalculaterVO(int su1, int su2) {
		this.su1 = su1;
		this.su2 = su2;
	}

	public int getSu1() {
		return su1;
	}

	public int getSu2() {
		return su2;
	}

	
	
}
