package com.spring.springTest.t12285;

public class SungjukVO {
	private String name;
	private int kor;
	private int eng;
	private int mat;
	private int tot;
	private double avg;
	private String grade;
	
	private SungjukService se = new SungjukService();

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMat() {
		return mat;
	}
	public void setMat(int mat) {
		this.mat = mat;
	}
	public int getTot() {
		return tot;
	}
	public void setTot(int tot) {
		this.tot = tot;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public SungjukService getSe() {
		return se;
	}
	public void setSe(SungjukService se) {
		this.se = se;
	}


	public void calcRes() {
		
		CalcVO cVo = se.calc(name, kor, eng, mat);
		this.tot = cVo.getTot();
		this.avg = cVo.getAvg();
		
		System.out.println(name+"님의 성적은 국어: "+kor+"점 영어: "+eng+"점 수학: "+mat);
		System.out.println("=============================================================================");
		System.out.println("총점 :"+cVo.getTot()+"점");
		System.out.println("평균 :"+cVo.getAvg()+"점");
		System.out.println("총점 :"+cVo.getGrade()+" !!");
		System.out.println("입니다.");
	}
	@Override
	public String toString() {
		return "SungjukVO [name=" + name + ", kor=" + kor + ", eng=" + eng + ", mat=" + mat + ", tot=" + tot + ", avg="
				+ avg + ", grade=" + grade + ", se=" + se + "]";
	}
}
