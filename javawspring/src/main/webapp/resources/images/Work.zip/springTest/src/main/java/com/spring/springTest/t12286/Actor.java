package com.spring.springTest.t12286;

public interface Actor {
	public void getCasting();
}
