package com.spring.springTest.t12271;

public class CalculaterRun {
	public static void main(String[] args) {
		
		
		Calculater cal = new Calculater();
		
		cal.setSu1(100);
		cal.setSu2(200);
		
		cal.add();
		cal.div();
		cal.mul();
		cal.sub();
		
	}
}
