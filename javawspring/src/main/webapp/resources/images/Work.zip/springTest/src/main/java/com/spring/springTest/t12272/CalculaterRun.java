package com.spring.springTest.t12272;

import java.util.Scanner;

public class CalculaterRun {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		CalculaterVO vo = new CalculaterVO();
		CalculaterService se = new CalculaterService();
		
		int res1 = 0;
		int res2 = 0;
		while(true) {
			System.out.println("첫번쨰 수를 입력하세요 종료 : 0");
			int su1 = sc.nextInt();
			if(su1 == 0) break;
			System.out.println("두번쨰 수를 입력하세요 종료 : 0");
			int su2 = sc.nextInt();
			if(su2 == 0) break;
			
				res1 = vo.setSu1(su1);
				res2 = vo.setSu2(su2);
				String y = "";
			if(res1 == 1 || res2 == 1) {
				System.out.println("숫자는 0보다 크고 100보다 작아야합니다.");
				System.out.println("숫자를 다시 입력하시겠습니까? Y/N");
				y = sc.next();
				if(!y.toUpperCase().equals("Y")) break;
				else continue;
			}
			else {
				
				se.add(vo.getSu1(),vo.getSu2());
				se.div(vo.getSu1(),vo.getSu2());
				se.mul(vo.getSu1(),vo.getSu2());
				se.sub(vo.getSu1(),vo.getSu2());
				
				System.out.println("작업을 계속 하시겠습니까? Y/N");
				if(!sc.next().toUpperCase().equals("Y")) {
					System.out.println("작업을 종료합니다..");
					break;
				}
				else continue;
			}
		}
		
		
		sc.close();
	}
}
