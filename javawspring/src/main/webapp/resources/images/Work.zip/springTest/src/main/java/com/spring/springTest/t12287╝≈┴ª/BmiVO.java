package com.spring.springTest.t12287숙제;

public class BmiVO {
	private int cm;
	private double kg;
	private String name;
	private double bmi;
	
	
	public double getBmi() {
		return bmi;
	}
	public void setBmi(double bmi) {
		this.bmi = bmi;
	}
	public void setCm(int cm) {
		this.cm = cm;
	}
	public void setKg(double kg) {
		this.kg = kg;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void BmiCalc() {
		
		BmiService se = new BmiService();
		
		this.bmi = se.BmiCalc(cm,kg);

		System.out.println(name+"님의 몸무게 : "+kg);
		System.out.println(name+"님의 키 : "+cm);
		System.out.println(name+"님의 BMI : "+String.valueOf(bmi).substring(0,4));
		String bRes = ""; 
		if(bmi < 18.5) {
			bRes = "저체중";
		}
		else if(bmi < 23) {
			bRes = "표준";
		}
		else if(bmi < 25) {
			bRes = "과체중";
		}
		else {
			bRes = "비만";
		}
		System.out.println("현재 BMI 수치로 보아 "+name+"님은 "+bRes+"입니다.");
	}
	
	
	
}
