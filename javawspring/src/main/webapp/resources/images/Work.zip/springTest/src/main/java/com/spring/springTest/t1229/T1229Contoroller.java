package com.spring.springTest.t1229;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/t1229")
public class T1229Contoroller {

	@RequestMapping(value = "/test1", method = RequestMethod.GET)
	public String test1Get(Model model) {
		
		model.addAttribute("data","볼링 비법 !!!");
		
		return "1229/test1";
	}
	
	@RequestMapping(value = "/test1", method = RequestMethod.POST)
//	public String test1OkGet(Model model,String name) {
		public String test1OkGet(Model model,String name) {
		
		
		model.addAttribute("data",name);
		
		return "1229/test1";
	}
	
	@RequestMapping(value = "/test2", method = RequestMethod.GET)
	public String test2Get() {
		
		return "1229/test2";
	}
}
