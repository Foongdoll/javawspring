package com.spring.springTest.t12285;

public class SungjukService {
	
	public CalcVO calc(String name, int kor, int eng, int mat) {
		CalcVO vo = new CalcVO();
		
		vo.setTot(kor+eng+mat);
		vo.setAvg((kor+eng+mat)/3);
		
		if(vo.getAvg() >= 90) vo.setGrade("A"); 
		else if (vo.getAvg() >= 80) vo.setGrade("B");
		else if (vo.getAvg() >= 70) vo.setGrade("C");
		else if (vo.getAvg() >= 60) vo.setGrade("D");
		else vo.setGrade("F");
		
		return vo;
	}

}
