package com.spring.springTest.t12287숙제;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
	비만도 구하는 공식 : 몸무게 / (키백분율 * 키백분율);
	저체중 : 18.5미만 , 표준 18.5~23 , 과체중 : 23~25 , 비만 : 25초과
	
*/
public class BmiRun {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("xml/BmiBeans.xml");
		
		BmiVO vo = (BmiVO)ctx.getBean("bBo");
		
		vo.BmiCalc();
		
		
	}
}
