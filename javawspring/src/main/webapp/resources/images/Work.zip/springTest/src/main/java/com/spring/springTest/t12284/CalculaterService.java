package com.spring.springTest.t12284;

public class CalculaterService {

	public void add(int su1, int su2) {
		System.out.println(su1+" + "+su2+" = "+(su1+su2));
	}
	public void sub(int su1, int su2) {
		System.out.println(su1+" - "+su2+" = "+(su1-su2));
	}
	public void mul(int su1, int su2) {
		System.out.println(su1+" * "+su2+" = "+(su1*su2));
	}
	public void div(int su1, int su2) {
		System.out.println(su1+" / "+su2+" = "+(su1/su2));
	}
	
}
