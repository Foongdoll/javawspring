package com.spring.springTest.t12286;

public class DoctorMan implements Actor {
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void getCasting() {
		System.out.println(name+"님는 의사입니다.");
	}

}
