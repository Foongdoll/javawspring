package com.spring.springTest.t12286;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ActorRun {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("xml/ActorBeans.xml");
		
//		PoliceMan pMan = (PoliceMan)ctx.getBean("pMan");
//		FireMan fMan = (FireMan)ctx.getBean("fMan");
//		DoctorMan dMan = (DoctorMan)ctx.getBean("dMan");
		
		Actor pMan = (PoliceMan)ctx.getBean("pMan");
		Actor fMan = (FireMan)ctx.getBean("fMan");
		Actor dMan = (DoctorMan)ctx.getBean("dMan");
		
		pMan.getCasting();
		fMan.getCasting();
		dMan.getCasting();
		
		ctx.close();
	}
}
