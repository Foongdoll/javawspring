package com.spring.springTest.t12282;

import java.util.Scanner;


// 값주입방법 (생성자를 이용한 값의 주입)
public class CalculaterRun {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("첫번쨰 수를 입력해주세요.");
		int su1 = sc.nextInt();
		System.out.println("두번쨰 수를 입력해주세요.");
		int su2 = sc.nextInt();
		CalculaterVO vo = new CalculaterVO(su1, su2);
		
		CalculaterService se = new CalculaterService();
		
		se.add(vo.getSu1(), vo.getSu2());
		se.sub(vo.getSu1(), vo.getSu2());
		se.mul(vo.getSu1(), vo.getSu2());
		se.div(vo.getSu1(), vo.getSu2());
		
		
	
		sc.close();
	}
}
