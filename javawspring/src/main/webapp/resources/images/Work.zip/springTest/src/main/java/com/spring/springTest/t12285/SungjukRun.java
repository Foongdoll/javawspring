package com.spring.springTest.t12285;

import java.util.ArrayList;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/*	성적 계산 : 성명/국어/영어/수학 점수를 xml로 입력받아 setter로 값을 주입한다.
 * 	
 * 	총점/평균/학점을 계산하는 프로그램 작성 (3명의 자료를 주입한다.)
 * */
public class SungjukRun {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("xml/sungjukBeans.xml");
		SungjukVO sVo;
		ArrayList<SungjukVO> vos = new ArrayList<>();
		String[] rank = new String[3];
		for(int i = 1; i <= 3; i++) {
			sVo = (SungjukVO)ctx.getBean("sVo"+i); 
			sVo.calcRes();
			vos.add(sVo);
			rank[i-1] = sVo.getName();
		}
		String temp = "";
			for(int i = 0; i < vos.size(); i++) {
				for(int j = 0; j < vos.size(); j++) {
					if(vos.get(i).getTot() > vos.get(j).getTot()) {
						temp = rank[i];
						rank[i] = rank[j];
						rank[j] = temp;
					}
				}
			}
			System.out.println("=================전체 순위====================");
			int j = 1;
			for(int i = 0 ; i <= 2; i++) {
				System.out.println("순위 "+j+"등 "+rank[i]+"님");
				j++;
			}
		
		ctx.close();	
	}
}
