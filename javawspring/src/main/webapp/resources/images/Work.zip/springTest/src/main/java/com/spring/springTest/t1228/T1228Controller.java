package com.spring.springTest.t1228;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/t1228")
public class T1228Controller  {
	
	@RequestMapping("/test1")
	public String test1Get(HttpServletRequest request, HttpServletResponse response) {

		return "1228/test1";
	}

	
	 @RequestMapping(value="/test2", method = RequestMethod.GET) public String
	 test2Get(HttpServletRequest request,HttpServletResponse response) {
		 
		 return "1228/test2"; 
	 }
	 
	 @RequestMapping(value="/test2", method = RequestMethod.POST) public String
	 test2Post(HttpServletRequest request,HttpServletResponse response) {
		 
		 return "1228/test2"; 
	 }
	 

	@RequestMapping(value = "/test3", method = RequestMethod.GET)
	public String test3Get(HttpServletRequest request, HttpServletResponse response) {

		return "1228/test3";
	}
	
	@RequestMapping(value = "/test4", method = RequestMethod.GET)
	public String test4Get(HttpServletRequest request, HttpServletResponse response) {
		
		request.setAttribute("name", "홍길동");
		
		return "1228/test4";
	}
	
//	@RequestMapping(value = "/test4", method = RequestMethod.POST)
//	public String test4Post(HttpServletRequest request, HttpServletResponse response) {
//		
//		request.setAttribute("name", "김말숙");
//		
//		return "1228/test4";
//	}
	
//	@RequestMapping(value = "/test4", method = RequestMethod.POST)
//	public String test4Post(HttpServletRequest request,HttpSession session,String name) {
//		
//		
//		session.setAttribute("name", name);
//		
//		return "1228/test4";
//	}
//	@RequestParam(name="name") 기본 
//	@RequestParam(name="name",defaultValue = "김연아")  널값처리 기본값을 넣어준다.
//	@RequestParam(name="name",defaultValue = "김연아",required = false) 무조건 입력해야함 안하면 김연아를 주겠음 
	  
//	@RequestMapping(value = "/test4", method = RequestMethod.POST)
//	public String test4Post(Model model,@RequestParam(name="name",defaultValue = "김연아",required = false) String nam) {
//		
//		model.addAttribute("name", nam);
//		
//		return "1228/test4";
//	}
	
	@RequestMapping(value = "/test4", method = RequestMethod.POST)
	public ModelAndView test4Post(ModelAndView mv,
			@RequestParam(name="name",defaultValue = "김연아",required = false) String nam) {
//		ModelAndView mv = new ModelAndView();
		
		
		mv.addObject("name", nam);
		mv.setViewName("1228/test4");
		
		return mv;
	}

	@RequestMapping(value = "/test5", method = RequestMethod.GET)
	public String test5Get(Model model) {
		
		model.addAttribute("name","홍길동");
		model.addAttribute("age","25");
		model.addAttribute("job","돌");
		model.addAttribute("address","길바닥");
		
		
		return "1228/test5";
	}
	
//	@RequestMapping(value = "/test5Ok", method = RequestMethod.POST)
//	public String test5Post(Model model, String name, int age, String job, String address,Test5VO vo) {
//		
//		vo.setName(name);
//		vo.setAge(age);
//		vo.setJob(job);
//		vo.setAddress(address);
//		
//		model.addAttribute("vo",vo);
//		
//		return "1228/test5Ok";
//	}
	@RequestMapping(value = "/test5Ok", method = RequestMethod.POST)
	public String test5Post(Model model, Test5VO vo) {
		
		model.addAttribute("vo",vo);
		
		return "1228/test5Ok";
	}
	
	
//	@RequestMapping(value = "/test6/{mid}/{pwd}", method = RequestMethod.GET)
//	public String test6Get(Model model,
//			@PathVariable String mid,@PathVariable String pwd) {
//		
//		model.addAttribute(mid);
//		model.addAttribute(pwd);
//		
//		return "1228/test6";
//	}
	
//	@RequestMapping(value = "/test6/{mid}/{pwd}", method = RequestMethod.GET)
//	public String test6Get(Model model,
//			@PathVariable String mid,@PathVariable String pwd) {
////		model.addAttribute(mid);
////		model.addAttribute(pwd);
//		
//		return "1228/test6";
//	}
	
//	@RequestMapping(value = "/test6/{buseo}/{mid}/{pwd}", method = RequestMethod.GET)
//	public String test6Get(Model model,
//			@PathVariable String buseo,
//			@PathVariable String mid,
//			@PathVariable String pwd) {
//		
//		model.addAttribute(mid);
//		model.addAttribute(pwd);
//		
//		if(buseo.equals("1")) 
//			return "1228/test7";
//		else 
//			return "1228/test8";
//		
//	}
//	
//	@RequestMapping(value = "/test6/{buseo}/{mid}/{pwd}", method = RequestMethod.GET)
//	public String test6Get(Model model,
//			@PathVariable String buseo,
//			@PathVariable String mid,
//			@PathVariable String pwd) {
//		
//		model.addAttribute("mid",mid);
//		model.addAttribute("pwd",pwd);
//		
//		if(buseo.equals("1")) 
//			return "redirect:/t1228/test77";
//		else 
//			return "redirect:/t1228/test88";
//		
//	}
//
//	@RequestMapping(value = "/test77", method = RequestMethod.GET)
//	public String test7Get(Model model,String mid,String pwd) {
//		
//		model.addAttribute("mid",mid);
//		model.addAttribute("pwd",pwd);
//		
//		return "1228/test7";
//	}
//	
//	
//	@RequestMapping(value = "/test88", method = RequestMethod.GET)
//	public String test8Get(Model model,String mid,String pwd) {
//		
//		model.addAttribute("mid",mid);
//		model.addAttribute("pwd",pwd);
//		
//		return "1228/test8";
//	}
	
	
	
	
	
}
