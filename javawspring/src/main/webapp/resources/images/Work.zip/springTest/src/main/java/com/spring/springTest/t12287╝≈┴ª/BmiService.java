package com.spring.springTest.t12287숙제;

public class BmiService {
	
	public double BmiCalc(int cm, double kg) {
		double bmi = 0.0;
		double cmb = cm/100.0;
		
		
		bmi = kg / (cmb * cmb);
		
		return bmi;
	}
	
}
