package com.spring.springTest.t12284;

public class CalculaterVO {
	private int su1;
	private int su2;
	
	private CalculaterService se = new CalculaterService();

	
	

	public void setSu1(int su1) {
		this.su1 = su1;
	}
	public void setSu2(int su2) {
		this.su2 = su2;
	}
	
	
	public void add() {
		se.add(su1, su2);
	}
	public void sub() {
		se.sub(su1, su2);
	}
	public void mul() {
		se.mul(su1, su2);
	}
	public void div() {
		se.div(su1, su2);
	}
	
}
